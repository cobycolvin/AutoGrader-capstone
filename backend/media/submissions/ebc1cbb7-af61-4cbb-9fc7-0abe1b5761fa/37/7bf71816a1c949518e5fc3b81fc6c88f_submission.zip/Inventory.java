public class Inventory {
    private String product;
    private int quantity;

    public Inventory(String product, int quantity) {
        this.product = product;
        this.quantity = quantity < 0 ? 0 : quantity;
    }

    public String getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void add(int amount) {
        switch (amount > 0 ? 1 : 0) {
            case 1:
                quantity = quantity + amount;
                break;
            default:
                break;
        }
    }

    public boolean remove(int amount) {
        boolean validAmount = amount > 0;
        boolean enoughStock = quantity >= amount;
        if (validAmount && enoughStock) {
            quantity = quantity - amount;
            return true;
        }
        return false;
    }
}
