public class Inventory {
    private final String itemName;
    private int count;

    public Inventory(String itemName, int count) {
        this.itemName = itemName;
        this.count = count;
    }

    public String getProduct() {
        return itemName;
    }

    public int getQuantity() {
        return count;
    }

    public void add(int amount) {
        if (amount <= 0) {
            return;
        }
        count += amount;
    }

    public boolean remove(int amount) {
        if (amount <= 0) {
            return false;
        }
        if (amount > count) {
            return false;
        }
        count -= amount;
        return true;
    }
}
