public class Inventory {
    private String product;
    private int quantity;

    public Inventory(String product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public String getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void add(int amount) {
        quantity += amount;
    }

    public boolean remove(int amount) {
        quantity -= amount;
        return true;
    }
}
