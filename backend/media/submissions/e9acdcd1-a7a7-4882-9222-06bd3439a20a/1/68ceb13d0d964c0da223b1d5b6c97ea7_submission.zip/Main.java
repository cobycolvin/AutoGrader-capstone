import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TreeMap<String, Integer> inventory = new TreeMap<>();

        if (!scanner.hasNextInt()) {
            System.out.println("EMPTY");
            System.out.println("TOTAL 0");
            return;
        }

        int commandCount = scanner.nextInt();

        for (int i = 0; i < commandCount; i++) {
            if (!scanner.hasNext()) {
                break;
            }

            String command = scanner.next();

            switch (command) {
                case "ADD": {
                    String sku = scanner.next();
                    int qty = scanner.nextInt();
                    inventory.put(sku, inventory.getOrDefault(sku, 0) + qty);
                    break;
                }
                case "SHIP": {
                    String sku = scanner.next();
                    int qty = scanner.nextInt();
                    int current = inventory.getOrDefault(sku, -1);
                    if (current >= qty) {
                        int updated = current - qty;
                        if (updated == 0) {
                            inventory.remove(sku);
                        } else {
                            inventory.put(sku, updated);
                        }
                    }
                    break;
                }
                case "SET": {
                    String sku = scanner.next();
                    int qty = scanner.nextInt();
                    if (qty <= 0) {
                        inventory.remove(sku);
                    } else {
                        inventory.put(sku, qty);
                    }
                    break;
                }
                case "DELETE": {
                    String sku = scanner.next();
                    inventory.remove(sku);
                    break;
                }
                case "RENAME": {
                    String oldSku = scanner.next();
                    String newSku = scanner.next();
                    if (inventory.containsKey(oldSku)) {
                        int qty = inventory.remove(oldSku);
                        inventory.put(newSku, inventory.getOrDefault(newSku, 0) + qty);
                    }
                    break;
                }
                default: {
                    if (scanner.hasNextLine()) {
                        scanner.nextLine();
                    }
                    break;
                }
            }
        }

        int total = 0;
        if (inventory.isEmpty()) {
            System.out.println("EMPTY");
        } else {
            for (Map.Entry<String, Integer> entry : inventory.entrySet()) {
                System.out.println(entry.getKey() + " " + entry.getValue());
                total += entry.getValue();
            }
        }

        if (inventory.isEmpty()) {
            total = 0;
        }

        System.out.println("TOTAL " + total);
    }
}
