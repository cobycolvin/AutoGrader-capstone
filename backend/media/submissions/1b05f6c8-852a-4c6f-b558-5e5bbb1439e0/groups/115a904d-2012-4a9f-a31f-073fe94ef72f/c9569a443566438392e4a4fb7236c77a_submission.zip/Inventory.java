public class Inventory {
    private String product;
    private int quantity;

    public Inventory(String product, int quantity) {
        this.product = product;
        this.quantity = quantity;
    }

    public String getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void add(int amount) {
        if (amount > 0) {
            quantity += amount;
        }
    }

    public boolean remove(int amount) {
        if (amount > 0 && quantity >= amount) {
            quantity -= amount;
            return true;
        }
        return false;
    }
}
