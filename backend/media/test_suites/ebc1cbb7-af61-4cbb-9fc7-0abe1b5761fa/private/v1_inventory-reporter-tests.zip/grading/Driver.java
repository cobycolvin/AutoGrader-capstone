import java.util.Scanner;

public class Driver {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String product = scanner.nextLine();
        int quantity = Integer.parseInt(scanner.nextLine());
        int addAmount = Integer.parseInt(scanner.nextLine());
        int removeAmount = Integer.parseInt(scanner.nextLine());

        Inventory inventory = new Inventory(product, quantity);

        inventory.add(addAmount);
        boolean removed = inventory.remove(removeAmount);

        System.out.println("PRODUCT " + inventory.getProduct());
        System.out.println("QUANTITY " + inventory.getQuantity());
        System.out.println("REMOVED " + (removed ? "YES" : "NO"));
    }
}
