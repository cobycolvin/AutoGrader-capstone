import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

def write_results(workspace, tests):
    path = os.path.join(workspace, "results.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump({"tests": tests}, handle, indent=2)

def _as_ms(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None

def _preview(value, limit=200):
    if isinstance(value, bytes):
        text = value.decode("utf-8", errors="replace")
    else:
        text = value if isinstance(value, str) else str(value)
    if len(text) <= limit:
        return text
    return text[:limit] + "..."

def _result(name, status, time_ms, message="", summary="", failure_kind="", details=None):
    payload = {
        "name": name,
        "status": status,
        "time_ms": time_ms,
        "message": message or "",
    }
    if summary:
        payload["summary"] = summary
    if failure_kind:
        payload["failure_kind"] = failure_kind
    if details:
        payload["details"] = details
    return payload

def _issue(kind, summary, **details):
    payload = {"kind": kind, "summary": summary}
    for key, value in details.items():
        if value is None or value == "":
            continue
        payload[key] = value
    return payload

def _failure_response(issues, fallback_message=""):
    issues = [issue for issue in (issues or []) if issue]
    if not issues:
        return False, {
            "summary": fallback_message or "Verification failed.",
            "failure_kind": "UNKNOWN_FAILURE",
            "details": {},
            "message": fallback_message or "Verification failed.",
        }
    if len(issues) == 1:
        issue = issues[0]
        details = {key: value for key, value in issue.items() if key not in {"kind", "summary"}}
        return False, {
            "summary": issue.get("summary", fallback_message or "Verification failed."),
            "failure_kind": issue.get("kind", "UNKNOWN_FAILURE"),
            "details": details,
            "message": issue.get("summary", fallback_message or "Verification failed."),
        }
    return False, {
        "summary": f"{len(issues)} verification checks failed.",
        "failure_kind": "MULTIPLE_FAILURES",
        "details": {"issues": issues},
        "message": " | ".join(issue.get("summary", "") for issue in issues if issue.get("summary")),
    }

def _safe_join(base, *parts):
    candidate = os.path.normpath(os.path.join(base, *parts))
    base_norm = os.path.normpath(base)
    if os.path.commonpath([base_norm, candidate]) != base_norm:
        raise ValueError("Unsafe path access")
    return candidate

def _read_text(path):
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()

def _read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)

def _list_files(base_dir):
    results = []
    for root, dir_names, file_names in os.walk(base_dir):
        dir_names[:] = [name for name in dir_names if name != ".classes"]
        for file_name in file_names:
            absolute = os.path.join(root, file_name)
            results.append(os.path.relpath(absolute, base_dir).replace("\\", "/"))
    return sorted(results)

def _normalize_whitespace(value):
    return " ".join((value or "").split())

def _normalize_lines(value):
    return sorted([(line or "").rstrip() for line in (value or "").splitlines()])

def _compare_text(actual, expected, mode, tolerance=None):
    actual = actual or ""
    expected = expected or ""
    mode = (mode or "EXACT").upper()
    try:
        if mode == "EXACT":
            passed = actual == expected
        elif mode == "TRIMMED":
            passed = actual.strip() == expected.strip()
        elif mode == "NORMALIZED_WHITESPACE":
            passed = _normalize_whitespace(actual) == _normalize_whitespace(expected)
        elif mode == "UNORDERED_LINES":
            passed = _normalize_lines(actual) == _normalize_lines(expected)
        elif mode == "JSON_EQ":
            passed = json.loads(actual) == json.loads(expected)
        elif mode == "NUMERIC_TOLERANCE":
            if tolerance is None:
                return False, "numeric_tolerance is required."
            passed = abs(float(actual.strip()) - float(expected.strip())) <= float(tolerance)
        else:
            return False, f"Unsupported comparison mode: {mode}"
    except Exception as exc:  # noqa: BLE001
        return False, f"{mode} comparison failed: {exc}"

    if passed:
        return True, ""
    return False, f"{mode} mismatch. expected={_preview(expected)!r} actual={_preview(actual)!r}"

def _prepare_case_dir(submission_dir, case_dir):
    shutil.copytree(submission_dir, case_dir, dirs_exist_ok=True)

def _write_grading_files(tests_dir, case_dir, payload):
    for fixture in payload.get("grading_files", []):
        source = _safe_join(tests_dir, fixture.get("source", ""))
        destination = _safe_join(case_dir, fixture.get("path", ""))
        os.makedirs(os.path.dirname(destination), exist_ok=True)
        shutil.copyfile(source, destination)

def _write_input_fixtures(tests_dir, case_dir, case):
    for fixture in case.get("input_files", []):
        source = _safe_join(tests_dir, fixture.get("source", ""))
        destination = _safe_join(case_dir, fixture.get("path", ""))
        os.makedirs(os.path.dirname(destination), exist_ok=True)
        shutil.copyfile(source, destination)

def _load_validator(tests_dir):
    validator_path = os.path.join(tests_dir, "validator.py")
    if not os.path.exists(validator_path):
        return None
    spec = importlib.util.spec_from_file_location("suite_validator", validator_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    validate_case = getattr(module, "validate_case", None)
    if not callable(validate_case):
        raise RuntimeError("validator.py must define validate_case(case, context)")
    return validate_case

def _build_validator_context(case_dir, submission_dir, stdout, stderr, exit_code):
    return {
        "case_dir": case_dir,
        "submission_dir": submission_dir,
        "stdout": stdout,
        "stderr": stderr,
        "exit_code": exit_code,
        "read_text": lambda path: _read_text(_safe_join(case_dir, path)),
        "read_json": lambda path: _read_json(_safe_join(case_dir, path)),
        "list_files": lambda: _list_files(case_dir),
    }

def _run_python_case(payload, case_dir, case, timeout_ms):
    entry_path = payload.get("entry_path")
    target = _safe_join(case_dir, entry_path)
    if not os.path.exists(target):
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": f"{entry_path} not found in submission",
            "timed_out": False,
            "error_kind": "MISSING_ENTRYPOINT",
            "error_summary": f"Entry script {entry_path} was not found in the submission.",
            "details": {
                "target": entry_path,
            },
        }
    proc = subprocess.run(
        [sys.executable, target, *list(case.get("args", []))],
        cwd=case_dir,
        input=case.get("stdin", ""),
        text=True,
        capture_output=True,
        timeout=(timeout_ms / 1000) if timeout_ms else None,
    )
    return {
        "returncode": proc.returncode,
        "stdout": proc.stdout or "",
        "stderr": proc.stderr or "",
        "timed_out": False,
    }

def _collect_java_sources(case_dir):
    sources = []
    for root, dir_names, file_names in os.walk(case_dir):
        dir_names[:] = [name for name in dir_names if name != ".classes"]
        for file_name in file_names:
            if file_name.endswith(".java"):
                sources.append(os.path.join(root, file_name))
    return sorted(sources)

def _run_java_case(payload, case_dir, case, timeout_ms):
    classes_dir = os.path.join(case_dir, ".classes")
    os.makedirs(classes_dir, exist_ok=True)
    source_files = _collect_java_sources(case_dir)
    if not source_files:
        return {
            "returncode": -1,
            "stdout": "",
            "stderr": "No .java files found in submission",
            "timed_out": False,
            "error_kind": "MISSING_SOURCE_FILES",
            "error_summary": "No Java source files were found in the submission.",
            "details": {},
        }

    compile_proc = subprocess.run(
        ["javac", "-d", classes_dir, *source_files],
        cwd=case_dir,
        text=True,
        capture_output=True,
    )
    if compile_proc.returncode != 0:
        return {
            "returncode": compile_proc.returncode,
            "stdout": compile_proc.stdout or "",
            "stderr": (compile_proc.stderr or compile_proc.stdout or "Compilation failed").strip(),
            "timed_out": False,
            "error_kind": "COMPILE_ERROR",
            "error_summary": "Java compilation failed before the program could run.",
            "details": {
                "stderr_preview": _preview(compile_proc.stderr or compile_proc.stdout or "Compilation failed"),
            },
        }

    proc = subprocess.run(
        ["java", "-cp", classes_dir, payload.get("main_class"), *list(case.get("args", []))],
        cwd=case_dir,
        input=case.get("stdin", ""),
        text=True,
        capture_output=True,
        timeout=(timeout_ms / 1000) if timeout_ms else None,
    )
    return {
        "returncode": proc.returncode,
        "stdout": proc.stdout or "",
        "stderr": proc.stderr or "",
        "timed_out": False,
    }

def _run_case(payload, case_dir, case, timeout_ms):
    language = (payload.get("language") or "").lower()
    if language == "python":
        return _run_python_case(payload, case_dir, case, timeout_ms)
    if language == "java":
        return _run_java_case(payload, case_dir, case, timeout_ms)
    return {
        "returncode": -1,
        "stdout": "",
        "stderr": f"Unsupported language: {language}",
        "timed_out": False,
        "error_kind": "UNSUPPORTED_LANGUAGE",
        "error_summary": f"Unsupported language for file-based execution: {language or 'unknown'}.",
        "details": {
            "language": language,
        },
    }

def _execution_issue(execution, expected_exit_code):
    error_kind = execution.get("error_kind")
    if error_kind:
        details = dict(execution.get("details") or {})
        details.setdefault("actual_exit_code", execution.get("returncode"))
        details.setdefault("stdout_preview", _preview(execution.get("stdout", "")))
        details.setdefault("stderr_preview", _preview(execution.get("stderr", "")))
        return _issue(
            error_kind,
            execution.get("error_summary") or "Execution failed before verification could complete.",
            **details,
        )

    actual_exit_code = execution.get("returncode")
    if actual_exit_code != expected_exit_code:
        failure_kind = "RUNTIME_ERROR" if expected_exit_code == 0 else "EXIT_CODE_MISMATCH"
        summary = (
            "The program exited with an error before completing the check."
            if failure_kind == "RUNTIME_ERROR"
            else f"Expected exit code {expected_exit_code}, but process returned {actual_exit_code}."
        )
        return _issue(
            failure_kind,
            summary,
            expected_exit_code=expected_exit_code,
            actual_exit_code=actual_exit_code,
            stdout_preview=_preview(execution.get("stdout", "")),
            stderr_preview=_preview(execution.get("stderr", "")),
        )

    return None

def _validate_built_in(tests_dir, case_dir, case, execution):
    issues = []
    expected_exit_code = int(case.get("expected_exit_code", 0))
    execution_issue = _execution_issue(execution, expected_exit_code)
    if execution_issue:
        return _failure_response([execution_issue])

    expected_stdout = case.get("expected_stdout")
    if expected_stdout is not None:
        ok, message = _compare_text(
            execution.get("stdout", ""),
            expected_stdout.get("content", ""),
            expected_stdout.get("comparison_mode"),
            expected_stdout.get("numeric_tolerance"),
        )
        if not ok:
            issues.append(
                _issue(
                    "STDOUT_MISMATCH",
                    "Stdout did not match the expected output.",
                    comparison_mode=expected_stdout.get("comparison_mode"),
                    expected_preview=_preview(expected_stdout.get("content", "")),
                    actual_preview=_preview(execution.get("stdout", "")),
                    comparison_message=message,
                )
            )

    expected_stderr = case.get("expected_stderr")
    if expected_stderr is not None:
        ok, message = _compare_text(
            execution.get("stderr", ""),
            expected_stderr.get("content", ""),
            expected_stderr.get("comparison_mode"),
            expected_stderr.get("numeric_tolerance"),
        )
        if not ok:
            issues.append(
                _issue(
                    "STDERR_MISMATCH",
                    "Stderr did not match the expected output.",
                    comparison_mode=expected_stderr.get("comparison_mode"),
                    expected_preview=_preview(expected_stderr.get("content", "")),
                    actual_preview=_preview(execution.get("stderr", "")),
                    comparison_message=message,
                )
            )

    for expected_file in case.get("expected_files", []):
        target_path = _safe_join(case_dir, expected_file.get("path", ""))
        if not os.path.exists(target_path):
            issues.append(
                _issue(
                    "MISSING_OUTPUT_FILE",
                    f"Expected output file {expected_file.get('path')} was not created.",
                    target=expected_file.get("path"),
                )
            )
            continue
        try:
            actual_content = _read_text(target_path)
        except Exception as exc:  # noqa: BLE001
            issues.append(
                _issue(
                    "OUTPUT_READ_ERROR",
                    f"Could not read output file {expected_file.get('path')}.",
                    target=expected_file.get("path"),
                    error=str(exc),
                )
            )
            continue

        expected_source = _safe_join(tests_dir, expected_file.get("source", ""))
        expected_content = _read_text(expected_source)
        ok, message = _compare_text(
            actual_content,
            expected_content,
            expected_file.get("comparison_mode"),
            expected_file.get("numeric_tolerance"),
        )
        if not ok:
            issues.append(
                _issue(
                    "OUTPUT_MISMATCH",
                    f"Output file {expected_file.get('path')} did not match the expected content.",
                    target=expected_file.get("path"),
                    comparison_mode=expected_file.get("comparison_mode"),
                    expected_preview=_preview(expected_content),
                    actual_preview=_preview(actual_content),
                    comparison_message=message,
                )
            )

    if issues:
        return _failure_response(issues)
    return True, {
        "summary": "All built-in checks passed.",
        "failure_kind": "",
        "details": {
            "args": list(case.get("args", [])),
            "input_preview": _preview(case.get("stdin", "")),
            "expected_stdout_preview": _preview((expected_stdout or {}).get("content", "")) if expected_stdout is not None else "",
            "actual_stdout_preview": _preview(execution.get("stdout", "")),
            "stderr_preview": _preview(execution.get("stderr", "")),
            "expected_exit_code": expected_exit_code,
            "actual_exit_code": execution.get("returncode"),
            "produced_files": _list_files(case_dir),
        },
        "message": "",
    }

def _validate_custom(validate_case, case, case_dir, submission_dir, execution):
    expected_exit_code = int(case.get("expected_exit_code", 0))
    execution_issue = _execution_issue(execution, expected_exit_code)
    if execution_issue:
        return _failure_response([execution_issue])
    issues = []

    context = _build_validator_context(
        case_dir,
        submission_dir,
        execution.get("stdout", ""),
        execution.get("stderr", ""),
        execution.get("returncode"),
    )
    result = validate_case(case, context)
    if not isinstance(result, dict):
        raise RuntimeError("validate_case must return a dict")
    validator_passed = bool(result.get("passed"))
    validator_message = str(result.get("message", "") or "").strip()
    if not validator_passed:
        issues.append(
            _issue(
                "VALIDATOR_FAILED",
                validator_message or "Custom validator reported a failure.",
                validator_message=validator_message,
                stdout_preview=_preview(execution.get("stdout", "")),
                stderr_preview=_preview(execution.get("stderr", "")),
            )
        )
    if issues:
        return _failure_response(issues, validator_message)
    return True, {
        "summary": "Custom validator accepted the submission output.",
        "failure_kind": "",
        "details": {
            "expected_exit_code": expected_exit_code,
            "actual_exit_code": execution.get("returncode"),
        },
        "message": validator_message,
    }

def main():
    if len(sys.argv) < 3:
        print("Usage: python run_tests.py <submission_dir> <workspace>")
        return 1

    submission_dir = sys.argv[1]
    workspace = sys.argv[2]
    tests_dir = os.path.dirname(__file__)
    tests_path = os.path.join(tests_dir, "tests.json")
    with open(tests_path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)

    results = []
    default_timeout = _as_ms(payload.get("timeout_ms"))
    validator = None
    validator_error = ""
    if any((case.get("validation_mode") or "BUILT_IN") == "CUSTOM" for case in payload.get("cases", [])):
        try:
            validator = _load_validator(tests_dir)
        except Exception as exc:  # noqa: BLE001
            validator_error = str(exc)

    for index, case in enumerate(payload.get("cases", []), start=1):
        case_name = case.get("name") or f"case-{index}"
        case_timeout = _as_ms(case.get("timeout_ms")) or default_timeout
        started_at = time.time()
        case_dir = tempfile.mkdtemp(prefix=f"case_{index}_", dir=workspace)
        try:
            _prepare_case_dir(submission_dir, case_dir)
            _write_grading_files(tests_dir, case_dir, payload)
            _write_input_fixtures(tests_dir, case_dir, case)
            try:
                execution = _run_case(payload, case_dir, case, case_timeout)
            except subprocess.TimeoutExpired as exc:
                results.append(
                    _result(
                        case_name,
                        "FAIL",
                        int((time.time() - started_at) * 1000),
                        message=f"Timeout after {case_timeout} ms" if case_timeout else "Timeout",
                        summary="Execution exceeded the time limit.",
                        failure_kind="TIMEOUT",
                        details={
                            "timeout_ms": case_timeout,
                            "stdout_preview": _preview(getattr(exc, "stdout", "") or ""),
                            "stderr_preview": _preview(getattr(exc, "stderr", "") or ""),
                        },
                    )
                )
                continue
            except FileNotFoundError as exc:
                results.append(
                    _result(
                        case_name,
                        "FAIL",
                        int((time.time() - started_at) * 1000),
                        message=str(exc),
                        summary="Required execution tool is not available on the grader worker.",
                        failure_kind="EXECUTION_TOOL_MISSING",
                        details={"error": str(exc)},
                    )
                )
                continue

            validation_mode = (case.get("validation_mode") or "BUILT_IN").upper()
            if validation_mode == "CUSTOM":
                if validator_error:
                    passed = False
                    feedback = {
                        "summary": "Custom validator could not be loaded.",
                        "failure_kind": "VALIDATOR_ERROR",
                        "details": {"error": validator_error},
                        "message": validator_error,
                    }
                elif validator is None:
                    passed = False
                    feedback = {
                        "summary": "Custom validator is missing from the test bundle.",
                        "failure_kind": "VALIDATOR_ERROR",
                        "details": {},
                        "message": "validator.py not available",
                    }
                else:
                    try:
                        passed, feedback = _validate_custom(
                            validator,
                            case,
                            case_dir,
                            submission_dir,
                            execution,
                        )
                    except Exception as exc:  # noqa: BLE001
                        passed = False
                        feedback = {
                            "summary": "Custom validator raised an exception.",
                            "failure_kind": "VALIDATOR_ERROR",
                            "details": {"error": str(exc)},
                            "message": f"Custom validator failed: {exc}",
                        }
            else:
                passed, feedback = _validate_built_in(tests_dir, case_dir, case, execution)

            results.append(
                _result(
                    case_name,
                    "PASS" if passed else "FAIL",
                    int((time.time() - started_at) * 1000),
                    message=(feedback.get("message") or execution.get("stderr", "").strip()),
                    summary=feedback.get("summary", ""),
                    failure_kind=feedback.get("failure_kind", ""),
                    details=feedback.get("details") or {},
                )
            )
        finally:
            shutil.rmtree(case_dir, ignore_errors=True)

    write_results(workspace, results)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
