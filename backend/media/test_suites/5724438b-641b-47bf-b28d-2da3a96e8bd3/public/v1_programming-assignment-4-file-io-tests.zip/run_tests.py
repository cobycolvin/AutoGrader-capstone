import json
import os
import pathlib
import subprocess
import sys
import time

def write_results(workspace, tests):
    path = os.path.join(workspace, "results.json")
    with open(path, "w", encoding="utf-8") as handle:
        json.dump({"tests": tests}, handle, indent=2)

def _as_ms(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None

def main():
    if len(sys.argv) < 3:
        print("Usage: python run_tests.py <submission_dir> <workspace>")
        return 1
    submission_dir = sys.argv[1]
    workspace = sys.argv[2]
    tests_path = os.path.join(os.path.dirname(__file__), "tests.json")
    with open(tests_path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)

    tests = []
    default_timeout = _as_ms(payload.get("timeout_ms"))
    main_class = (payload.get("main_class") or "Main").strip() or "Main"
    java_files = [str(path) for path in pathlib.Path(submission_dir).rglob("*.java")]
    if not java_files:
        tests.append({
            "name": "java_files_exist",
            "status": "FAIL",
            "time_ms": 0,
            "message": "No .java files found in submission",
        })
        write_results(workspace, tests)
        return 0

    classes_dir = os.path.join(workspace, ".io-classes")
    os.makedirs(classes_dir, exist_ok=True)
    compile_start = time.time()
    compile_proc = subprocess.run(
        ["javac", "-d", classes_dir, *java_files],
        cwd=submission_dir,
        text=True,
        capture_output=True,
    )
    compile_elapsed = int((time.time() - compile_start) * 1000)
    if compile_proc.returncode != 0:
        tests.append({
            "name": "compile",
            "status": "FAIL",
            "time_ms": compile_elapsed,
            "message": (compile_proc.stderr or compile_proc.stdout or "Compilation failed").strip(),
        })
        write_results(workspace, tests)
        return 0

    for test in payload.get("tests", []):
        start = time.time()
        timeout = _as_ms(test.get("timeout_ms")) or default_timeout
        case_name = test.get("name") or "case"
        try:
            proc = subprocess.run(
                ["java", "-cp", classes_dir, main_class],
                cwd=submission_dir,
                input=test.get("input", ""),
                text=True,
                capture_output=True,
                timeout=(timeout / 1000) if timeout else None,
            )
            output = (proc.stdout or "").strip()
            expected = (test.get("expected") or "").strip()
            passed = proc.returncode == 0 and output == expected
            tests.append({
                "name": case_name,
                "status": "PASS" if passed else "FAIL",
                "time_ms": int((time.time() - start) * 1000),
                "message": "" if passed else ((proc.stderr or "").strip() or f"expected={expected!r} actual={output!r}"),
            })
        except subprocess.TimeoutExpired:
            tests.append({
                "name": case_name,
                "status": "FAIL",
                "time_ms": int((time.time() - start) * 1000),
                "message": f"Timeout after {timeout} ms" if timeout else "Timeout",
            })
        except Exception as exc:  # noqa: BLE001
            tests.append({
                "name": case_name,
                "status": "FAIL",
                "time_ms": int((time.time() - start) * 1000),
                "message": str(exc),
            })
    write_results(workspace, tests)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
